import { useRef } from "react"

export default function Slide4({dispatch}) {
    const slideId=useRef()
    return (
        <div id="slide4" className="col-12 " ref={slideId}>
            <div className="form_sec col-lg-6 offset-lg-3 col-md-8 offset-md-2 col-12 ">
                <h2>Do you want to check your eligibility for a Prepaid Spending Card loaded with up to $540?</h2>
                <div className="col-md-10 offset-md-1 col-12">
                    <label className="icon_option text-white" htmlFor="no3">
                        <input tabIndex={1} type="radio" className="sctop1 next04" id="no3" defaultValue={11} autoComplete="off" 
                        onClick={()=>dispatch({type:"slide",payload:slideId.current.id})}
                        />
                        <span>Yes</span>
                    </label>
                    <label className="icon_option text-white" htmlFor="yes3">
                        <input tabIndex={1} type="radio" className="sctop1 next04" id="yes3" defaultValue={11} autoComplete="off" 
                        onClick={()=>dispatch({type:"slide",payload:slideId.current.id})}
                        />
                        <span>No</span>
                    </label>
                </div>
                <div className="col-lg-12 p-0 ">
                    <input type="button" className="btn back_btn back03"  data-direction="prev" defaultValue="<< Back"
                    onClick={()=>dispatch({type:"back",payload:slideId.current.id})}
                    />
                </div>
            </div>
        </div>
    )
}

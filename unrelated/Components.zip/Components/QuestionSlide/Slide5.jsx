import { useEffect, useState } from "react";
import { spin } from "../../assets/assetImgs";

const formatTime = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;
    return `${hours < 10 ? '0' : ''}${hours}:${minutes < 10 ? '0' : ''}${minutes}:${remainingSeconds < 10 ? '0' : ''}${remainingSeconds}`;
};
export default function Slide5() {
    // const slideId=useRef()
    const [load, setLoad] = useState(true)
    const [time, setTime] = useState(0)

    useEffect(() => {
        const timer = setTimeout(() => {
            setLoad(prev => !prev)
            const intervel = setInterval(() => {
                setTime(prev => prev + 1)
            }, 1000)
            return () => clearInterval(intervel)
            // console.log("timeout");
        }, 2000)
        // if (!load) {
        // }

        return () => {
            clearTimeout(timer)
            // if(intervel) {clearInterval(intervel)}
        }
    }, [])
    return (
        <>
            {load ?
                <div id="myDiv" className="space text-center">
                    <img src={spin} alt="spin" style={{ width: 150, marginTop: 30 }} />
                    <h3 className="p-0 text11">Checking your Eligibility</h3>
                </div> :
                <div id="slide5" className="col-12 ">
                    <div className="form_sec  col-lg-6 offset-lg-3 col-md-8 offset-md-2 col-12 ">
                        <h2>Great News!</h2>
                        <h5 className="mb-3">You may be eligible for <b>$0/Month Health Insurance That Covers Medical Expenses</b>
                        </h5>
                        <h5 className="mb-3">
                            <b>Last Step:</b> You must <b>
                                <a className="text-black">Call Now</a>
                            </b> to review your options and benefits before your enrollment period ends.
                        </h5>
                        <h5 className="mb-3">
                            <b>It only takes 2 minutes</b>
                        </h5>
                        <h2 className="mt-3">Tap to Call Now</h2>
                        <div className="col-md-10 offset-md-1 col-12">
                            <label className="icon_option text-white" htmlFor="num1">
                                <input tabIndex={1} type="radio" className="sctop1 " id="num1" defaultValue={11} autoComplete="off" />
                                <span>(888) 888-8888</span>
                            </label>
                            <h5 className="mt-3">Act Fast! An Agent is Waiting For Your Call</h5>
                            <h5>
                                <span className="txt_clr" id="time" >{formatTime(time)}</span>
                            </h5>
                            <p className="slid_txt2">By placing a call to our business, you consent to receive marketing and non-marketing
                                calls and text messages from us and our agents and affiliates using an automatic telephone dialing system
                                and/or prerecorded voice, even if you do not provide your phone number or are on a government do-not-call
                                registry. You are not required to give consent to receive calls as a condition of doing business with us.
                                If at any time you wish to opt-out of receiving calls, please contact us using the contact information
                                provided on our website.</p>
                        </div>
                    </div>
                </div>
            }
        </>
    )
}

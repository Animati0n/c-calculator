import { useRef } from "react";
import { rightArrow } from "../../assets/assetImgs";

export default function Slide1({dispatch}) {
    const slideId=useRef()
    return (
        <div id="slide1" className="col-12" ref={slideId}>
            <div className="form_sec col-lg-6 offset-lg-3 col-md-8 offset-md-2 col-12 ">
                <h2>AFFORDABLE CARE ACT UPDATE</h2>
                <h5>Americans in [State] That Make Under $540 Could Qualify For Free Healthcare That Covers Healthcare Expenses!</h5>
                <p>Thanks to a State Regulated Program, Americans Get Free Healthcare Benefits Before The Deadline</p>
                <h4>Click Below To Qualify Now</h4>
                <div className=" col-md-10 offset-md-1 col-12">
                    <label className="icon_option text-white" htmlFor="Council1">
                        <input tabIndex={1} type="radio" className="sctop1 next01" id="Council1" defaultValue={11} data-direction="next" autoComplete="off"
                        onClick={()=>dispatch({type:"slide",payload:slideId.current.id})}
                        />
                        <span>See If I Qualify <img src={rightArrow} alt="rightArrow" />
                        </span>
                    </label>
                </div>
            </div>
        </div>
    )
}

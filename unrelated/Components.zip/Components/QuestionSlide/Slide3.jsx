import { useRef } from "react"

export default function Slide3({dispatch}) {
    const slideId=useRef()
    return (
        <div id="slide3" className="col-12 " ref={slideId}>
            <div className="form_sec col-lg-6 offset-lg-3 col-md-8 offset-md-2 col-12 ">
                <h2>Are You Under 65 Years Old?</h2>
                <div className="col-md-10 offset-md-1 col-12">
                    <label className="icon_option text-white" htmlFor="yes1">
                        <input tabIndex={1} type="radio" className="sctop1 next03" id="yes1" data-direction="next" defaultValue={11} autoComplete="off" 
                        onClick={()=>dispatch({type:"slide",payload:slideId.current.id})}
                        />
                        <span>Yes</span>
                    </label>
                    <label className="icon_option text-white" htmlFor="no1">
                        <input tabIndex={1} type="radio" className="sctop1 next03" id="no1" data-direction="next" defaultValue={11} autoComplete="off" 
                        onClick={()=>dispatch({type:"slide",payload:slideId.current.id})}
                        />
                        <span>No I'm Not</span>
                    </label>
                </div>
                <div className="col-lg-12 p-0 ">
                    <input type="button" className="btn back_btn back02"  data-direction="prev" defaultValue="<< Back"
                    onClick={()=>dispatch({type:"back",payload:slideId.current.id})}
                    
                    />
                </div>
            </div>
        </div>
    )
}

import { logo } from "../assets/assetImgs";

export default function Navbar() {
    return (
        <header>
            <div className="container">
                <div className="row">
                    <div className="col-12 ">
                        <img src={logo} alt="logo" />
                    </div>
                </div>
            </div>
        </header>
    )
}

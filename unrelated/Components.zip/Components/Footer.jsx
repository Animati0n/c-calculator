
export default function Footer() {
    return (
        <footer id="footer1" className="py-4 ">
            <div className="container">
                <div className="offset-lg-1 col-lg-10">
                    <div className="row mb-3">
                        <div>
                            <p style={{ marginBottom: 0 }}>© 2013-2022 | <a target="_blank"  href="#">Privacy Policy</a> | <a target="_blank"  href="#">Terms of Use</a> | <a target="_blank" rel="noopener noreferrer nofollow" href="#">Cookies Policy</a></p>
                            <p>London Bridge Media, LLC - 4425 Bayard St, Suite 210, San Diego, CA 92109</p>
                        </div>
                        <div className=" py-2">
                            <p>Disclaimer: London Bridge Media, LLC is not connected with or endorsed by the United States government or the Federal Medicare program. Essential Medicare Leads is not an insurance company, is not a representative or an agent to any broker or insurance company, does not represent Medicare Advantage (MA) Plans, Medicare Supplement, and Prescription Drug Plans (PDP) with Medicare contracts. The information you provide will be submitted to a broker and/or an insurance provider. This website does not constitute an offer or solicitation for insurance. There is absolutely no obligation to purchase anything. The brokers and or insurance providers do not offer every plan available in your area, any information we provide is limited to those plans the brokers and insurance providers represent. Please contact Medicare.gov or 1-800-MEDICARE to get information on all of your options. This information is available in other languages.All trademarks and copyrights are the property of their respective owners. </p>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
    )
}
